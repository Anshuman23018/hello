
# OOPD_ASSIGNMENT 1

This read me is for Assignment 1 Question 1:

About the code:
The code calculates the actual money received after the given year using the interest rate as well as the amount of money recevied after certain years using the net rate (interest rate-inflation rate).
we read the data using csv file and stores it an array of Structure.

Steps required:

1- Go to the file directory where you have written the code. 

2- Run Windows Powershell in the project directory.

3- Type "mingw32-make"
 /*Then two files will be created.
i).debug_program.exe
ii).optimized_execution.exe */

To run the code

4- type ".\debug_program.exe" for debugging
 or
  ".\ optimized_execution.exe" for optimized program




